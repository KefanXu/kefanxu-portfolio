import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { BACKDROP_FRAGMENT, FIELD_FRAGMENT, GLASS_FRAGMENT, GLASS_VERTEX, QUAD_VERTEX, SCREEN_FRAGMENT, SCREEN_VERTEX } from './shaders';

/*
 * The glass hero. One unit is one CSS pixel on the z = 0 plane, so layout can
 * be reasoned about in the same terms as the DOM around it.
 *
 *   backdrop pass  → light field + drifting screens + the headline
 *   composite pass → backdrop, the headline again (crisp), then the glass slab,
 *                    which refracts the backdrop texture
 */
export interface HeadlineRun { text: string; serif?: boolean }
export interface ScreenSpec { src: string; w: number; x: number; y: number; z: number; rot: number; aspect: number }

export interface GlassSceneOptions {
  host: HTMLElement;
  /** Empty block in the DOM flow where the headline is drawn. */
  slot: HTMLElement;
  lines: HeadlineRun[][];
  screens: ScreenSpec[];
  onReady?: () => void;
  /** The machine cannot hold a usable frame rate even at low quality. */
  onTooSlow?: () => void;
  /** Start at low quality (also `?gl=lite`). */
  lite?: boolean;
}

export interface GlassScene {
  setProgress(progress: number): void;
  setVisible(visible: boolean): void;
  resize(): void;
  dispose(): void;
}

const RIPPLE_W = 144;
const RIPPLE_H = 96;
const MAX_DPR = 1.75;
const MAX_PIXELS = 2.6e6;
const CAMERA_Z = 1400;

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export function createGlassScene(options: GlassSceneOptions): GlassScene {
  const { host, slot, lines, screens: screenSpecs, onReady, onTooSlow } = options;
  const disposables: { dispose(): void }[] = [];
  const own = <T extends { dispose(): void }>(item: T) => { disposables.push(item); return item; };

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance', stencil: false });
  renderer.setClearColor(0x070a0d, 1);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.domElement.className = 'glass-hero__canvas';
  renderer.domElement.setAttribute('aria-hidden', 'true');
  host.appendChild(renderer.domElement);

  const camera = new THREE.PerspectiveCamera(30, 1, 10, 6000);
  camera.position.set(0, 0, CAMERA_Z);

  // ── Backdrop pass: light field, screens, headline ─────────────────────
  const backdropScene = new THREE.Scene();
  const fieldMaterial = own(new THREE.ShaderMaterial({
    vertexShader: QUAD_VERTEX,
    fragmentShader: FIELD_FRAGMENT,
    uniforms: { uTime: { value: 0 }, uRes: { value: new THREE.Vector2(1, 1) }, uLift: { value: 0 } },
    depthTest: false,
    depthWrite: false,
  }));
  // The field is soft by nature, so it is rendered small and stretched.
  const fieldScene = new THREE.Scene();
  const fieldTarget = own(new THREE.WebGLRenderTarget(2, 2, { depthBuffer: false, stencilBuffer: false }));
  const fieldQuad = new THREE.Mesh(own(new THREE.PlaneGeometry(2, 2)), fieldMaterial);
  fieldQuad.frustumCulled = false;
  fieldScene.add(fieldQuad);
  const fieldCopyMaterial = own(new THREE.ShaderMaterial({
    vertexShader: QUAD_VERTEX,
    fragmentShader: /* glsl */ `
      uniform sampler2D uMap; varying vec2 vUv;
      void main() { gl_FragColor = texture2D(uMap, vUv); }
    `,
    uniforms: { uMap: { value: fieldTarget.texture } },
    depthTest: false,
    depthWrite: false,
  }));
  const fieldCopy = new THREE.Mesh(fieldQuad.geometry, fieldCopyMaterial);
  fieldCopy.frustumCulled = false;
  fieldCopy.renderOrder = -10;
  backdropScene.add(fieldCopy);

  const loader = new THREE.TextureLoader();
  const screenGroup = new THREE.Group();
  backdropScene.add(screenGroup);
  interface ScreenMesh { mesh: THREE.Mesh; spec: ScreenSpec; material: THREE.ShaderMaterial; phase: number }
  const screens: ScreenMesh[] = screenSpecs.map((spec, index) => {
    const material = own(new THREE.ShaderMaterial({
      vertexShader: SCREEN_VERTEX,
      fragmentShader: SCREEN_FRAGMENT,
      uniforms: {
        uMap: { value: null },
        uSize: { value: new THREE.Vector2(1, 1) },
        uUvScale: { value: new THREE.Vector2(1, 1) },
        uUvOffset: { value: new THREE.Vector2(0, 0) },
        uRadius: { value: 24 },
        uDim: { value: 0.6 },
        uFade: { value: 0 },
      },
      transparent: true,
      depthTest: false,
      depthWrite: false,
    }));
    const mesh = new THREE.Mesh(own(new THREE.PlaneGeometry(1, 1)), material);
    mesh.renderOrder = index;
    screenGroup.add(mesh);
    loader.load(spec.src, texture => {
      texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
      texture.minFilter = THREE.LinearMipmapLinearFilter;
      material.uniforms.uMap.value = texture;
      // cover-fit the image into the plane's aspect, anchored to the top
      const image = texture.image as { width: number; height: number };
      const imageAspect = image.width / image.height;
      if (imageAspect > spec.aspect) {
        const sx = spec.aspect / imageAspect;
        material.uniforms.uUvScale.value.set(sx, 1);
        material.uniforms.uUvOffset.value.set((1 - sx) / 2, 0);
      } else {
        const sy = imageAspect / spec.aspect;
        material.uniforms.uUvScale.value.set(1, sy);
        material.uniforms.uUvOffset.value.set(0, 1 - sy);
      }
      disposables.push(texture);
    });
    return { mesh, spec, material, phase: index * 1.7 };
  });

  // Headline as a canvas texture. Drawn once fonts are in, redrawn on resize.
  const textCanvas = document.createElement('canvas');
  const textContext = textCanvas.getContext('2d')!;
  const textTexture = own(new THREE.CanvasTexture(textCanvas));
  textTexture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  // Pass-through sampling keeps the canvas pixels as authored in both passes.
  const textMaterial = own(new THREE.ShaderMaterial({
    vertexShader: SCREEN_VERTEX,
    fragmentShader: /* glsl */ `
      uniform sampler2D uMap; uniform float uOpacity; varying vec2 vUv;
      void main() { vec4 c = texture2D(uMap, vUv); gl_FragColor = vec4(c.rgb, c.a * uOpacity); }
    `,
    uniforms: { uMap: { value: textTexture }, uOpacity: { value: 1 } },
    transparent: true,
    depthTest: false,
    depthWrite: false,
  }));
  const textMesh = new THREE.Mesh(own(new THREE.PlaneGeometry(1, 1)), textMaterial);
  textMesh.renderOrder = 50;
  backdropScene.add(textMesh);
  // The same mesh is drawn crisp in the composite pass; three allows one
  // object in one scene only, so keep a twin that shares geometry and material.
  const textTwin = new THREE.Mesh(textMesh.geometry, textMaterial);
  textTwin.renderOrder = 5;

  // ── Composite pass: backdrop → crisp headline → glass ─────────────────
  const scene = new THREE.Scene();
  const backdropTarget = own(new THREE.WebGLRenderTarget(2, 2, { depthBuffer: false, stencilBuffer: false }));
  const backdropMaterial = own(new THREE.ShaderMaterial({
    vertexShader: QUAD_VERTEX,
    fragmentShader: BACKDROP_FRAGMENT,
    uniforms: { uMap: { value: backdropTarget.texture }, uTime: { value: 0 } },
    depthTest: false,
    depthWrite: false,
  }));
  const backdropQuad = new THREE.Mesh(fieldQuad.geometry, backdropMaterial);
  backdropQuad.frustumCulled = false;
  backdropQuad.renderOrder = -10;
  scene.add(backdropQuad);
  scene.add(textTwin);

  // Ripple simulation on the CPU, uploaded as an 8-bit height map.
  let heightA = new Float32Array(RIPPLE_W * RIPPLE_H);
  let heightB = new Float32Array(RIPPLE_W * RIPPLE_H);
  const rippleBytes = new Uint8Array(RIPPLE_W * RIPPLE_H).fill(128);
  const rippleTexture = own(new THREE.DataTexture(rippleBytes, RIPPLE_W, RIPPLE_H, THREE.RedFormat, THREE.UnsignedByteType));
  rippleTexture.minFilter = rippleTexture.magFilter = THREE.LinearFilter;
  rippleTexture.wrapS = rippleTexture.wrapT = THREE.ClampToEdgeWrapping;
  rippleTexture.needsUpdate = true;

  const glassMaterial = own(new THREE.ShaderMaterial({
    vertexShader: GLASS_VERTEX,
    fragmentShader: GLASS_FRAGMENT,
    uniforms: {
      uBackdrop: { value: backdropTarget.texture },
      uRipple: { value: rippleTexture },
      uRes: { value: new THREE.Vector2(1, 1) },
      uSize: { value: new THREE.Vector2(1, 1) },
      uDepth: { value: 1 },
      uRippleTexel: { value: new THREE.Vector2(1 / RIPPLE_W, 1 / RIPPLE_H) },
      uTime: { value: 0 },
      uIor: { value: 1.48 },
      uDispersion: { value: 0.07 },
      uThickness: { value: 0.15 },
      uRough: { value: 0.0009 },
      uFlow: { value: 0.85 },
      uWobble: { value: 14 },
      uTint: { value: new THREE.Color(0.7, 0.86, 0.9) },
    },
  }));
  let glassGeometry: THREE.BufferGeometry | null = null;
  const glass = new THREE.Mesh(new THREE.BufferGeometry(), glassMaterial);
  glass.renderOrder = 100;
  scene.add(glass);
  const glassPivot = new THREE.Group();
  glassPivot.add(glass);
  scene.add(glassPivot);

  // ── State ─────────────────────────────────────────────────────────────
  let width = 1;
  let height = 1;
  let dpr = 1;
  let lite = Boolean(options.lite);
  let frameEma = 0;
  let framesSeen = 0;
  let progress = 0;
  let visible = true;
  let running = true;
  let raf = 0;
  let last = performance.now();
  let time = 0;
  let fontsReady = false;
  const pointer = { x: 0, y: 0, tx: 0, ty: 0, inside: false };
  const lastHit = { x: -1, y: -1 };
  const raycaster = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  const glassBase = { x: 0, y: 0, z: 90, w: 700, h: 500, d: 120 };
  const slotRect = { left: 0, top: 0, width: 1, height: 1 };

  function fitCamera() {
    camera.aspect = width / height;
    camera.fov = (2 * Math.atan(height / 2 / CAMERA_Z) * 180) / Math.PI;
    camera.updateProjectionMatrix();
  }

  /** Screen px (relative to the canvas) → world units on the z = 0 plane. */
  const toWorldX = (px: number) => px - width / 2;
  const toWorldY = (py: number) => height / 2 - py;

  function layout() {
    const hostRect = host.getBoundingClientRect();
    width = Math.max(1, Math.round(hostRect.width));
    height = Math.max(1, Math.round(hostRect.height));
    dpr = lite ? 1 : Math.min(MAX_DPR, window.devicePixelRatio || 1);
    if (width * height * dpr * dpr > MAX_PIXELS) dpr = Math.max(1, Math.sqrt(MAX_PIXELS / (width * height)));
    renderer.setPixelRatio(dpr);
    renderer.setSize(width, height, false);
    // The backdrop can be softer than the canvas; the crisp headline is drawn on top.
    const backdropScale = lite ? 0.6 : 1;
    backdropTarget.setSize(Math.round(width * dpr * backdropScale), Math.round(height * dpr * backdropScale));
    fitCamera();
    fieldTarget.setSize(Math.max(2, Math.round(width * 0.25)), Math.max(2, Math.round(height * 0.25)));
    fieldMaterial.uniforms.uRes.value.set(Math.round(width * 0.25), Math.round(height * 0.25));
    glassMaterial.uniforms.uRes.value.set(width * dpr, height * dpr);

    // Glass slab: right of centre, overlapping the end of the headline.
    const narrow = width < 1200;
    const w = THREE.MathUtils.clamp(width * (narrow ? 0.38 : 0.41), 340, 780);
    const h = THREE.MathUtils.clamp(height * 0.64, 360, 720);
    const d = THREE.MathUtils.clamp(Math.min(w, h) * 0.22, 64, 130);
    glassBase.w = w; glassBase.h = h; glassBase.d = d;
    glassBase.x = toWorldX(width * (narrow ? 0.735 : 0.705));
    glassBase.y = toWorldY(height * 0.53);
    glassBase.z = d * 0.6 + 40;
    glassGeometry?.dispose();
    glassGeometry = new RoundedBoxGeometry(w, h, d, 10, d / 2);
    glass.geometry = glassGeometry;
    glassMaterial.uniforms.uSize.value.set(w, h);
    glassMaterial.uniforms.uDepth.value = d;

    // Screens are specified in fractions of the host; depth pushes them back.
    screens.forEach(({ mesh, spec, material }) => {
      const sw = spec.w * width;
      const sh = sw / spec.aspect;
      mesh.scale.set(sw, sh, 1);
      mesh.position.set(toWorldX(spec.x * width), toWorldY(spec.y * height), spec.z);
      mesh.rotation.z = spec.rot;
      material.uniforms.uSize.value.set(sw, sh);
      material.uniforms.uRadius.value = sw * 0.085;
    });

    // Headline slot → text plane.
    const rect = slot.getBoundingClientRect();
    slotRect.left = rect.left - hostRect.left;
    slotRect.top = rect.top - hostRect.top;
    slotRect.width = Math.max(1, rect.width);
    slotRect.height = Math.max(1, rect.height);
    textMesh.scale.set(slotRect.width, slotRect.height, 1);
    textMesh.position.set(toWorldX(slotRect.left + slotRect.width / 2), toWorldY(slotRect.top + slotRect.height / 2), 0);
    textTwin.scale.copy(textMesh.scale);
    textTwin.position.copy(textMesh.position);
    drawHeadline();
  }

  function drawHeadline() {
    const size = parseFloat(getComputedStyle(slot).fontSize) || 64;
    const lineHeight = size * 0.93;
    const cw = Math.ceil(slotRect.width * dpr);
    const ch = Math.ceil(slotRect.height * dpr);
    if (textCanvas.width !== cw || textCanvas.height !== ch) { textCanvas.width = cw; textCanvas.height = ch; }
    const ctx = textContext;
    // Feature-detect the newer text properties; browsers without them draw a
    // slightly wider headline, which is fine because nothing is twinned in the DOM.
    const loose = ctx as unknown as Record<string, unknown>;
    const stretchable = typeof loose.fontStretch === 'string';
    const spacing = typeof loose.letterSpacing === 'string';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, slotRect.width, slotRect.height);
    ctx.textBaseline = 'alphabetic';
    const sansFont = `460 ${size}px "Instrument Sans", "Helvetica Neue", Arial, sans-serif`;
    const serifFont = `italic 400 ${size * 1.045}px "Instrument Serif", "Times New Roman", serif`;

    lines.forEach((runs, lineIndex) => {
      let x = 0;
      const baseline = lineIndex * lineHeight + size * 0.86;
      runs.forEach(run => {
        ctx.save();
        if (run.serif) {
          ctx.font = serifFont;
          if (spacing) loose.letterSpacing = '-0.02em';
          ctx.fillStyle = '#b9f0e2';
        } else {
          ctx.font = sansFont;
          if (stretchable) loose.fontStretch = 'semi-condensed';
          if (spacing) loose.letterSpacing = '-0.046em';
          ctx.fillStyle = '#eef1f3';
        }
        if (!stretchable && !run.serif) {
          ctx.translate(x, 0);
          ctx.scale(0.88, 1);
          ctx.fillText(run.text, 0, baseline);
          x += ctx.measureText(run.text).width * 0.88;
        } else {
          ctx.fillText(run.text, x, baseline);
          x += ctx.measureText(run.text).width;
        }
        ctx.restore();
      });
    });
    textTexture.needsUpdate = true;
  }

  // ── Pointer → ripples and parallax ────────────────────────────────────
  function dropAt(u: number, v: number, strength: number, radius: number) {
    const cx = u * RIPPLE_W;
    const cy = v * RIPPLE_H;
    const r = Math.ceil(radius);
    for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(RIPPLE_H - 1, Math.ceil(cy + r)); y++) {
      for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(RIPPLE_W - 1, Math.ceil(cx + r)); x++) {
        const dx = x - cx;
        const dy = y - cy;
        const dist2 = dx * dx + dy * dy;
        if (dist2 > radius * radius) continue;
        heightA[y * RIPPLE_W + x] += strength * (1 - Math.sqrt(dist2) / radius);
      }
    }
  }

  function stepRipples() {
    const damping = 0.968;
    for (let y = 1; y < RIPPLE_H - 1; y++) {
      const row = y * RIPPLE_W;
      for (let x = 1; x < RIPPLE_W - 1; x++) {
        const i = row + x;
        const next = ((heightA[i - 1] + heightA[i + 1] + heightA[i - RIPPLE_W] + heightA[i + RIPPLE_W]) * 0.5 - heightB[i]) * damping;
        heightB[i] = next;
      }
    }
    const swap = heightA; heightA = heightB; heightB = swap;
    for (let i = 0; i < rippleBytes.length; i++) {
      rippleBytes[i] = Math.max(0, Math.min(255, 128 + heightA[i] * 255));
    }
    rippleTexture.needsUpdate = true;
  }

  const onPointerMove = (event: PointerEvent) => {
    const rect = renderer.domElement.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    pointer.inside = x >= 0 && y >= 0 && x <= rect.width && y <= rect.height;
    if (!pointer.inside) return;
    pointer.tx = x / rect.width - 0.5;
    pointer.ty = y / rect.height - 0.5;
    ndc.set((x / rect.width) * 2 - 1, -(y / rect.height) * 2 + 1);
    raycaster.setFromCamera(ndc, camera);
    const hit = raycaster.intersectObject(glass, false)[0];
    if (!hit) { lastHit.x = -1; return; }
    const local = glass.worldToLocal(hit.point.clone());
    const u = local.x / glassBase.w + 0.5;
    const v = local.y / glassBase.h + 0.5;
    if (lastHit.x >= 0) {
      const speed = Math.hypot(u - lastHit.x, v - lastHit.y);
      const strength = Math.min(0.09, 0.012 + speed * 0.9);
      dropAt(u, v, strength, 3.2 + Math.min(3, speed * 40));
    } else {
      dropAt(u, v, 0.03, 3);
    }
    lastHit.x = u; lastHit.y = v;
  };
  const onPointerLeave = () => { pointer.inside = false; lastHit.x = -1; };
  window.addEventListener('pointermove', onPointerMove, { passive: true });
  document.documentElement.addEventListener('pointerleave', onPointerLeave);

  // ── Frame ─────────────────────────────────────────────────────────────
  function frame(now: number) {
    raf = requestAnimationFrame(frame);
    if (!visible || !running) return;
    const rawDt = (now - last) / 1000;
    const dt = Math.min(0.05, rawDt);
    last = now;
    time += dt;

    // Adaptive quality: a machine that cannot keep up drops to low quality,
    // and one that still cannot hands the hero back to the DOM.
    if (framesSeen++ > 10) {
      frameEma = frameEma ? frameEma * 0.9 + rawDt * 0.1 : rawDt;
      if (framesSeen === 70 || framesSeen === 200) {
        if (frameEma > 0.034 && !lite) { lite = true; framesSeen = 11; frameEma = 0; layout(); }
        else if (frameEma > 0.07 && lite) { running = false; onTooSlow?.(); return; }
      }
    }

    pointer.x = lerp(pointer.x, pointer.inside ? pointer.tx : 0, 0.05);
    pointer.y = lerp(pointer.y, pointer.inside ? pointer.ty : 0, 0.05);

    // glass: floats, tilts toward the pointer, and lifts away as the page scrolls
    const rise = progress * height * 0.55;
    glassPivot.position.set(glassBase.x + pointer.x * 18, glassBase.y + rise + Math.sin(time * 0.6) * 6, glassBase.z);
    glassPivot.rotation.set(
      -0.06 + pointer.y * -0.14 + Math.sin(time * 0.43) * 0.02 + progress * 0.35,
      -0.16 + pointer.x * 0.2 + Math.cos(time * 0.37) * 0.025 - progress * 0.5,
      0.03 + Math.sin(time * 0.29) * 0.01 + progress * 0.12,
    );

    // screens: parallax by depth, slow bob, sink slightly as the page scrolls
    screens.forEach(({ mesh, spec, material, phase }) => {
      const depth = -spec.z / 900;
      const fade = material.uniforms.uFade.value;
      if (material.uniforms.uMap.value && fade < 1) material.uniforms.uFade.value = Math.min(1, fade + dt * 0.9);
      mesh.position.x = toWorldX(spec.x * width) - pointer.x * 70 * depth;
      mesh.position.y = toWorldY(spec.y * height) - pointer.y * 40 * depth + Math.sin(time * 0.5 + phase) * 7 - progress * height * (0.18 + 0.25 * depth);
      mesh.rotation.z = spec.rot + Math.sin(time * 0.3 + phase) * 0.01;
    });

    fieldMaterial.uniforms.uTime.value = time;
    fieldMaterial.uniforms.uLift.value = progress;
    glassMaterial.uniforms.uTime.value = time;
    backdropMaterial.uniforms.uTime.value = time;
    stepRipples();

    textMaterial.uniforms.uOpacity.value = 1 - progress * 0.9;

    renderer.setRenderTarget(fieldTarget);
    renderer.render(fieldScene, camera);
    renderer.setRenderTarget(backdropTarget);
    renderer.render(backdropScene, camera);
    renderer.setRenderTarget(null);
    renderer.render(scene, camera);
  }

  // ── Boot ──────────────────────────────────────────────────────────────
  const fontLoads = document.fonts
    ? Promise.all([
        document.fonts.load('460 100px "Instrument Sans"'),
        document.fonts.load('italic 400 100px "Instrument Serif"'),
      ]).catch(() => undefined)
    : Promise.resolve(undefined);
  const timeout = new Promise<void>(resolve => window.setTimeout(resolve, 1500));
  Promise.race([fontLoads, timeout]).then(() => {
    fontsReady = true;
    layout();
    onReady?.();
    if (!raf) raf = requestAnimationFrame(frame);
  });

  const resizeObserver = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(() => { if (fontsReady) layout(); });
  resizeObserver?.observe(host);
  const onVisibility = () => { running = document.visibilityState !== 'hidden'; last = performance.now(); };
  document.addEventListener('visibilitychange', onVisibility);

  return {
    setProgress(value) { progress = Math.max(0, Math.min(1, value)); },
    setVisible(value) { if (value && !visible) last = performance.now(); visible = value; },
    resize() { if (fontsReady) layout(); },
    dispose() {
      cancelAnimationFrame(raf);
      resizeObserver?.disconnect();
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pointermove', onPointerMove);
      document.documentElement.removeEventListener('pointerleave', onPointerLeave);
      glassGeometry?.dispose();
      disposables.forEach(item => item.dispose());
      renderer.dispose();
      renderer.domElement.remove();
    },
  };
}
