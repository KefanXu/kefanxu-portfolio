import { img } from './img';
import type { Shot } from './types';

const rootImg = (path: string) => `${import.meta.env.BASE_URL}images/${path}`;

/*
 * What the lens uncovers under each project's screens: a piece of the research
 * paper trail (flyer, study plan, wireframes), a field note in my own words,
 * and two numbers from the study. Nothing here is a participant quote.
 */
export interface Beneath {
  label: string;
  figure: Shot;
  caption: string;
  note: string;
  stats: { value: string; label: string }[];
}

export const beneath: Record<string, Beneath> = {
  trackya: {
    label: 'Recruitment · phase one',
    figure: { src: img('trackya/flyer-1.webp'), alt: 'Trackya recruitment flyer: joining a study, three interviews, six weeks.' },
    caption: 'Flyer for the first study phase, before any screen existed.',
    note: 'The interface is one hour wide because the interviews were: people talked about their day in hours, not in steps.',
    stats: [{ value: '3', label: 'study phases' }, { value: '4', label: 'context filters' }],
  },
  moodloop: {
    label: 'Study design · six weeks',
    figure: { src: img('moodloop/study.webp'), alt: 'Moodloop study plan: three weeks of daily reports without annotation, three with, and three interviews.' },
    caption: 'Two three-week blocks with an interview between them.',
    note: 'The scale had to belong to the person, so the study let them change it and watched what happened next.',
    stats: [{ value: '42', label: 'days in the field' }, { value: '594', label: 'reports in study windows' }],
  },
  carework: {
    label: 'Wireframes · assignment flow',
    figure: { src: img('carework/wireframes.webp'), alt: 'CareWork wireframes: the assignment, task and review screens before visual design.' },
    caption: 'Low-fidelity flow reviewed with clinicians before any AI drafting was designed.',
    note: 'Fourteen healthcare professionals told me where an AI draft would help and where it must stay out of the way.',
    stats: [{ value: '11', label: 'prototype sessions' }, { value: '14', label: 'healthcare professionals' }],
  },
  planneregy: {
    label: 'Wireframe · tracking',
    figure: { src: img('planneregy/wf-tracking.webp'), alt: 'Planneregy tracking wireframe: a weekly plan with unreported activities and a strategy name.' },
    caption: 'Tracking screen as a wireframe, when strategies still had working titles.',
    note: 'Six weeks of deployment showed plans changing more than we expected, so change became the feature.',
    stats: [{ value: '16', label: 'participants completed' }, { value: '434', label: 'activity plans created' }],
  },
  ecocare: {
    label: 'Framework · care ecology',
    figure: { src: rootImg('care-ecology.webp'), alt: 'Diagram of a care ecology: the person, their relationships and their context in concentric rings.' },
    caption: 'The ecological model the interface visualises, drawn before the interface.',
    note: 'Twenty-two patient interviews came first; the concentric map is how they described change reaching them.',
    stats: [{ value: '22', label: 'foundational interviews' }, { value: '3', label: 'ecological layers' }],
  },
  physicify: {
    label: 'Wireboard · iOS',
    figure: { src: img('physicify/wireboard.webp'), alt: 'Physicify wireboard: plan, report and history screens sketched as wireframes.' },
    caption: 'The whole app on one board before Swift.',
    note: 'A month in the field, half of it with history visible, to see whether hindsight changes how people plan.',
    stats: [{ value: '28', label: 'days in the field' }, { value: '70.4%', label: 'average completion' }],
  },
};
