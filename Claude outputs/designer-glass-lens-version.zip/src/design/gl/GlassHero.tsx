import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { holdRevealGate, releaseRevealGate } from '../components/Reveal';
import { coarsePointer, onScrollFrame, reducedMotion } from '../lib/scroll';
import type { GlassScene, HeadlineRun, ScreenSpec } from './glassScene';

function supportsGlass(): boolean {
  try {
    // `?gl=force` keeps the scene on for software renderers (useful when checking headless).
    const flag = new URLSearchParams(window.location.search).get('gl');
    const forced = flag === 'force' || flag === 'lite';
    const canvas = document.createElement('canvas');
    return Boolean(canvas.getContext('webgl2', { failIfMajorPerformanceCaveat: !forced }));
  } catch {
    return false;
  }
}

/*
 * Mounts the WebGL glass scene behind the hero's DOM. The headline is drawn in
 * the scene (so the glass can refract it) inside the space the real <h1>
 * reserves; assistive tech reads the <h1>'s hidden text. Small screens,
 * reduced motion and machines without WebGL 2 get the DOM hero instead.
 */
export function useGlassHero(): [boolean | null, () => void] {
  const [enabled, setEnabled] = useState<boolean | null>(null);
  useEffect(() => {
    const wide = window.matchMedia('(min-width: 900px)').matches;
    setEnabled(wide && !reducedMotion() && supportsGlass());
  }, []);
  const disable = useCallback(() => setEnabled(false), []);
  return [enabled, disable];
}

interface GlassHeroProps {
  host: React.RefObject<HTMLElement>;
  slot: React.RefObject<HTMLHeadingElement>;
  lines: HeadlineRun[][];
  screens: ScreenSpec[];
  onTooSlow?: () => void;
  children?: ReactNode;
}

export function GlassHero({ host, slot, lines, screens, onTooSlow }: GlassHeroProps) {
  const ready = useRef(false);

  useEffect(() => {
    const section = host.current;
    const heading = slot.current;
    if (!section || !heading) return;
    let disposed = false;
    let scene: GlassScene | null = null;
    let progress = 0;
    let visible = true;
    // The rest of the hero waits for the glass, so the page arrives as one
    // piece rather than text first and glass later — but never for long.
    holdRevealGate('glass');
    const release = () => releaseRevealGate('glass');
    const patience = window.setTimeout(release, 3000);
    // three.js only reaches devices that will use it.
    import('./glassScene').then(({ createGlassScene }) => {
      if (disposed) return;
      scene = createGlassScene({
        host: section,
        slot: heading,
        lines,
        screens,
        lite: new URLSearchParams(window.location.search).get('gl') === 'lite',
        onReady: () => {
          if (disposed) return;
          ready.current = true;
          section.classList.add('is-glass-ready');
          release();
        },
        onTooSlow: () => { if (!disposed) onTooSlow?.(); },
      });
      scene.setProgress(progress);
      scene.setVisible(visible);
    }).catch(() => { if (!disposed) onTooSlow?.(); });
    const stopScroll = onScrollFrame(({ y, vh }) => { progress = y / (vh * 0.9); scene?.setProgress(progress); });
    const observer = new IntersectionObserver(entries => { visible = entries.some(entry => entry.isIntersecting); scene?.setVisible(visible); }, { rootMargin: '80px 0px' });
    observer.observe(section);
    // A touch drag also ripples the glass; nothing else needs the pointer here.
    if (coarsePointer()) section.classList.add('is-touch');
    return () => {
      disposed = true;
      window.clearTimeout(patience);
      release();
      stopScroll();
      observer.disconnect();
      scene?.dispose();
      section.classList.remove('is-glass-ready');
    };
  }, [host, slot, lines, screens, onTooSlow]);

  return null;
}
