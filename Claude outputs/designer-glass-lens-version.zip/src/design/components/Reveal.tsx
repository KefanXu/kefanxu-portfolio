import { createElement, useEffect, useRef, type CSSProperties, type ReactNode } from 'react';
import { onScrollFrame } from '../lib/scroll';

/*
 * Scroll reveals. One IntersectionObserver marks elements `.is-in`; CSS does
 * the rest (see styles/base.css). A gate lets the app hold reveals while a
 * curtain or page wipe is still covering the viewport, so entrances are seen.
 */
let gateOpen = false;
const waiting = new Set<Element>();
const pending = new Set<Element>();
/** Elements that should show as soon as any part of them is on screen (no bottom margin). */
const eager = new Set<Element>();
const observers: { lazy?: IntersectionObserver; eager?: IntersectionObserver } = {};
let sweeping: (() => void) | null = null;

function show(element: Element) {
  pending.delete(element);
  eager.delete(element);
  if (gateOpen) element.classList.add('is-in');
  else waiting.add(element);
}
function onEntries(entries: IntersectionObserverEntry[], io: IntersectionObserver) {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    io.unobserve(entry.target);
    show(entry.target);
  });
}
function getObserver(isEager: boolean) {
  const key = isEager ? 'eager' : 'lazy';
  const existing = observers[key];
  if (existing) return existing;
  const io = new IntersectionObserver(onEntries, isEager ? { threshold: 0 } : { rootMargin: '0px 0px -9% 0px', threshold: 0.01 });
  observers[key] = io;
  // Belt and braces: some renderers pause intersection notifications while a
  // WebGL canvas is drawing, so each scroll frame also sweeps what is pending.
  sweeping ??= onScrollFrame(({ vh }) => {
    pending.forEach(element => {
      const rect = element.getBoundingClientRect();
      const limit = eager.has(element) ? vh : vh * 0.91;
      if (rect.bottom <= 0 || rect.top >= limit || (rect.width === 0 && rect.height === 0)) return;
      observers.lazy?.unobserve(element);
      observers.eager?.unobserve(element);
      show(element);
    });
  });
  return io;
}
let wantOpen = false;
const holds = new Set<string>();
function applyGate() {
  const open = wantOpen && holds.size === 0;
  if (open === gateOpen) return;
  gateOpen = open;
  if (!open) return;
  waiting.forEach(element => element.classList.add('is-in'));
  waiting.clear();
}
export function setRevealGate(open: boolean) {
  wantOpen = open;
  applyGate();
}
/** Keep the gate shut while something (the glass hero booting) is not ready to be seen. */
export function holdRevealGate(key: string) { holds.add(key); applyGate(); }
export function releaseRevealGate(key: string) { holds.delete(key); applyGate(); }

/**
 * Marks the element `.is-in` once it scrolls into view; style the entrance in CSS.
 * Reveals normally wait until the element clears the bottom 9% of the viewport;
 * `isEager` shows it as soon as any of it is on screen (for cues that sit at the
 * fold, like the hero's scroll hint).
 */
export function useRevealRef<T extends Element>(clipped = false, isEager = false) {
  const ref = useRef<T | null>(null);
  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    // Chromium applies an element's own clip-path when it computes intersections,
    // so a fully clipped element never reports as visible. Clip reveals are
    // tracked by their layout box on the shared scroll loop instead.
    if (clipped) {
      const stop = onScrollFrame(({ vh }) => {
        const rect = element.getBoundingClientRect();
        if (rect.bottom <= 0 || rect.top >= vh * 0.91) return;
        stop();
        show(element);
      });
      return () => {
        stop();
        waiting.delete(element);
      };
    }

    const io = getObserver(isEager);
    io.observe(element);
    pending.add(element);
    if (isEager) eager.add(element);
    return () => {
      io.unobserve(element);
      pending.delete(element);
      eager.delete(element);
      waiting.delete(element);
    };
  }, [clipped, isEager]);
  return ref;
}

type Tag = 'div' | 'section' | 'article' | 'figure' | 'li' | 'p' | 'span' | 'header' | 'footer' | 'ul' | 'ol' | 'dl' | 'a' | 'h2' | 'h3' | 'h4';

interface RevealProps {
  as?: Tag;
  kind?: 'up' | 'fade' | 'scale' | 'clip';
  delay?: number;
  /** Show as soon as any part is on screen instead of waiting for it to clear the fold. */
  eager?: boolean;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
  [attribute: string]: unknown;
}
export function Reveal({ as = 'div', kind = 'up', delay = 0, eager: isEager = false, className, style, children, ...rest }: RevealProps) {
  const ref = useRevealRef<HTMLElement>(kind === 'clip', isEager);
  return createElement(
    as,
    { ref, className, 'data-reveal': kind, style: { ...style, '--d': `${delay}ms` } as CSSProperties, ...rest },
    children,
  );
}

interface SplitTextProps {
  /** Words wrapped in *asterisks* are set in the italic serif. */
  text: string;
  as?: 'h1' | 'h2' | 'h3' | 'p' | 'span' | 'div';
  className?: string;
  delay?: number;
  id?: string;
}
export function SplitText({ text, as = 'p', className = '', delay = 0, id }: SplitTextProps) {
  const ref = useRevealRef<HTMLElement>();
  let emphasised = false;
  const words = text.split(/\s+/).filter(Boolean).map(token => {
    let word = token;
    let italic = emphasised;
    if (word.startsWith('*')) { italic = true; emphasised = true; word = word.slice(1); }
    if (/\*[.,;:!?—–-]*$/.test(word)) { emphasised = false; word = word.replace('*', ''); }
    return { word, italic };
  });
  const plain = words.map(item => item.word).join(' ');

  return createElement(
    as,
    { ref, id, className: `split ${className}`.trim(), style: { '--d': `${delay}ms` } as CSSProperties },
    <span className="sr-only" key="sr">{plain}</span>,
    words.map((item, index) => (
      <span key={index} aria-hidden="true">
        <span className="split__word">
          <span style={{ '--i': index } as CSSProperties}>{item.italic ? <em>{item.word}</em> : item.word}</span>
        </span>
        {index < words.length - 1 ? ' ' : null}
      </span>
    )),
  );
}

export function Rule({ delay = 0, className = '' }: { delay?: number; className?: string }) {
  const ref = useRevealRef<HTMLSpanElement>();
  return <span ref={ref} className={`rule ${className}`.trim()} style={{ '--d': `${delay}ms` } as CSSProperties} aria-hidden="true" />;
}
