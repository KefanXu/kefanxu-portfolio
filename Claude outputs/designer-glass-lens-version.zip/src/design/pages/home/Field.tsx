import { useCallback, useEffect, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from 'react';
import { ArrowUpRight, Layers } from 'lucide-react';
import { Cover } from '../../components/Covers';
import { Reveal, SplitText } from '../../components/Reveal';
import { beneath } from '../../data/beneath';
import { projects } from '../../data/projects';
import type { Project } from '../../data/types';
import { useRouter, workHref } from '../../lib/router';
import { coarsePointer, onScrollFrame, reducedMotion, refreshScroll } from '../../lib/scroll';

const clamp = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/*
 * The field: six glass panes in a row that the page scroll carries past the
 * viewport. A lens follows the pointer; wherever it rests on a pane, the glass
 * gives way to the paper underneath — the study plan, the wireframes, the
 * flyer — with a field note and two numbers. On touch and keyboard the lens is
 * a button that lifts the whole pane instead.
 */
function Pane({ project, index, open, onToggle }: { project: Project; index: number; open: boolean; onToggle: () => void }) {
  const { link } = useRouter();
  const href = workHref(project.slug);
  const info = beneath[project.slug];

  const onPointerMove = (event: ReactPointerEvent<HTMLAnchorElement>) => {
    if (coarsePointer()) return;
    const bounds = event.currentTarget.getBoundingClientRect();
    event.currentTarget.style.setProperty('--px', (((event.clientX - bounds.left) / bounds.width) * 2 - 1).toFixed(3));
    event.currentTarget.style.setProperty('--py', (((event.clientY - bounds.top) / bounds.height) * 2 - 1).toFixed(3));
  };
  const onPointerLeave = (event: ReactPointerEvent<HTMLAnchorElement>) => {
    event.currentTarget.style.setProperty('--px', '0');
    event.currentTarget.style.setProperty('--py', '0');
  };

  return (
    <li className={`pane${open ? ' is-beneath' : ''}`} data-pane style={{ '--accent': project.theme.accent, '--i': index } as CSSProperties}>
      <a
        className="pane__link"
        href={href}
        onClick={link(href)}
        onPointerMove={onPointerMove}
        onPointerLeave={onPointerLeave}
        data-cover-host
        aria-label={`${project.name}: ${project.summary} Open the case study.`}
      >
        <div className="pane__text">
          <div className="pane__top mono">
            <span>{String(index + 1).padStart(2, '0')} / {String(projects.length).padStart(2, '0')}</span>
            <span>{project.kicker}</span>
          </div>
          <div className="pane__body">
            <h3 className="pane__name">{project.name}</h3>
            <p className="pane__summary">{project.summary}</p>
            <ul className="pane__tags mono">{project.tags.slice(0, 3).map(tag => <li key={tag}>{tag}</li>)}</ul>
          </div>
          <div className="pane__foot">
            <span className="pane__go"><span>Open case study</span><i aria-hidden="true"><ArrowUpRight size={20} /></i></span>
            <span className="mono pane__year">{project.year}<br />{project.status}</span>
          </div>
        </div>
        <div className="pane__glass" style={{ '--panel': project.theme.panel, '--panel-ink': project.theme.ink } as CSSProperties}>
          <div className="pane__surface"><Cover id={project.cover} /></div>
          {info && (
            <div className="pane__beneath" data-beneath aria-hidden={!open}>
              <div className="pane__beneath-head mono"><span>Beneath the glass</span><span>{info.label}</span></div>
              <figure className="pane__beneath-figure"><img src={info.figure.src} alt={info.figure.alt} loading="lazy" decoding="async" /></figure>
              <div className="pane__beneath-foot">
                <blockquote>{info.note}</blockquote>
                <dl>{info.stats.map(stat => <div key={stat.label}><dt>{stat.value}</dt><dd>{stat.label}</dd></div>)}</dl>
              </div>
            </div>
          )}
        </div>
      </a>
      {info && (
        <button type="button" className="pane__toggle mono" aria-pressed={open} onClick={onToggle}>
          <Layers size={14} aria-hidden="true" />{open ? 'Back to the screen' : 'Look beneath'}
        </button>
      )}
    </li>
  );
}

export function Field() {
  const section = useRef<HTMLElement>(null);
  const pin = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLOListElement>(null);
  const lensRef = useRef<HTMLDivElement>(null);
  const lensLabel = useRef<HTMLSpanElement>(null);
  const [open, setOpen] = useState<string | null>(null);
  const horizontal = useRef(false);
  const pointer = useRef({ x: -9999, y: -9999, lx: -9999, ly: -9999, on: false, raf: 0 });

  const layout = useCallback(() => {
    const element = section.current;
    const list = track.current;
    if (!element || !list) return;
    horizontal.current = window.matchMedia('(min-width: 901px)').matches;
    if (horizontal.current) {
      const overflow = Math.max(0, list.scrollWidth - window.innerWidth);
      element.style.height = `${window.innerHeight + overflow}px`;
    } else {
      element.style.height = '';
      list.style.transform = '';
    }
    refreshScroll();
  }, []);

  /** Position the lens and re-aim every pane's mask at it. */
  const aim = useCallback(() => {
    const state = pointer.current;
    const lens = lensRef.current;
    const panes = track.current?.querySelectorAll<HTMLElement>('[data-pane]');
    if (!lens || !panes) return;
    const smooth = reducedMotion() ? 1 : 0.16;
    state.lx = state.lx < -9000 ? state.x : lerp(state.lx, state.x, smooth);
    state.ly = state.ly < -9000 ? state.y : lerp(state.ly, state.y, smooth);
    let overPane = false;
    panes.forEach(pane => {
      const glass = pane.querySelector<HTMLElement>('.pane__glass');
      const paper = pane.querySelector<HTMLElement>('[data-beneath]');
      if (!glass || !paper) return;
      const rect = glass.getBoundingClientRect();
      const mx = state.lx - rect.left;
      const my = state.ly - rect.top;
      paper.style.setProperty('--mx', `${mx.toFixed(1)}px`);
      paper.style.setProperty('--my', `${my.toFixed(1)}px`);
      if (mx > -40 && my > -40 && mx < rect.width + 40 && my < rect.height + 40) overPane = true;
    });
    lens.classList.toggle('is-over', overPane);
    lens.style.transform = `translate3d(${state.lx.toFixed(1)}px, ${state.ly.toFixed(1)}px, 0) scale(${!state.on ? 0.6 : overPane ? 1 : 0.72})`;
    if (lensLabel.current) lensLabel.current.textContent = 'Beneath the glass · click to open';
    const settled = Math.abs(state.lx - state.x) + Math.abs(state.ly - state.y) < 0.2;
    state.raf = state.on || !settled ? requestAnimationFrame(aim) : 0;
  }, []);

  useEffect(() => {
    layout();
    const onResize = () => layout();
    window.addEventListener('resize', onResize);
    // Images inside the panes change the track width as they load.
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(() => layout());
    if (track.current) observer?.observe(track.current);
    return () => { window.removeEventListener('resize', onResize); observer?.disconnect(); };
  }, [layout]);

  useEffect(() => onScrollFrame(({ y, vh, vw }) => {
    const element = section.current;
    const list = track.current;
    if (!element || !list) return;
    const panes = list.querySelectorAll<HTMLElement>('[data-pane]');
    if (horizontal.current) {
      const top = element.getBoundingClientRect().top + y;
      const total = Math.max(1, element.offsetHeight - vh);
      const progress = clamp((y - top) / total);
      const overflow = Math.max(0, list.scrollWidth - vw);
      list.style.transform = `translate3d(${(-progress * overflow).toFixed(2)}px, 0, 0)`;
      panes.forEach(pane => {
        const rect = pane.getBoundingClientRect();
        pane.style.setProperty('--sp', clamp(1 - (rect.left + rect.width / 2) / vw).toFixed(4));
      });
      if (pointer.current.on && !pointer.current.raf) pointer.current.raf = requestAnimationFrame(aim);
    } else {
      panes.forEach(pane => {
        const rect = pane.getBoundingClientRect();
        pane.style.setProperty('--sp', clamp((vh - rect.top) / (vh + rect.height)).toFixed(4));
      });
    }
  }), [aim]);

  useEffect(() => {
    const element = pin.current;
    if (!element || coarsePointer()) return;
    const state = pointer.current;
    const onMove = (event: PointerEvent) => {
      state.x = event.clientX;
      state.y = event.clientY;
      if (!state.on) { state.on = true; lensRef.current?.classList.add('is-on'); }
      if (!state.raf) state.raf = requestAnimationFrame(aim);
    };
    const onLeave = () => {
      state.on = false;
      lensRef.current?.classList.remove('is-on');
      if (!state.raf) state.raf = requestAnimationFrame(aim);
    };
    element.addEventListener('pointermove', onMove, { passive: true });
    element.addEventListener('pointerleave', onLeave);
    return () => {
      element.removeEventListener('pointermove', onMove);
      element.removeEventListener('pointerleave', onLeave);
      cancelAnimationFrame(state.raf);
      state.raf = 0;
    };
  }, [aim]);

  return (
    <section ref={section} className="field" id="work" aria-labelledby="work-title">
      <div ref={pin} className="field__pin">
        <div className="shell field__head">
          <SplitText as="h2" id="work-title" className="h2" text="Selected *work*" />
          <Reveal kind="fade" className="field__hint mono" delay={200}><i aria-hidden="true" />Move the lens over a project to see the research beneath</Reveal>
          <Reveal className="field__count mono" delay={260}>({String(projects.length).padStart(2, '0')}) case studies · 2021 — 2026</Reveal>
        </div>
        <ol ref={track} className="field__track">
          {projects.map((project, index) => (
            <Pane key={project.slug} project={project} index={index} open={open === project.slug} onToggle={() => setOpen(current => (current === project.slug ? null : project.slug))} />
          ))}
        </ol>
        <div ref={lensRef} className="lens" aria-hidden="true"><span ref={lensLabel} className="lens__label mono">Move over a project</span></div>
      </div>
    </section>
  );
}
