/*
 * GLSL for the glass hero. Three passes share these: the light field and the
 * screens are drawn into a backdrop texture, the headline is drawn crisp on
 * top, and the glass slab refracts the backdrop texture through a rippling,
 * dispersive surface.
 */

export const NOISE = /* glsl */ `
  float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
  float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i), b = hash21(i + vec2(1.0, 0.0)), c = hash21(i + vec2(0.0, 1.0)), d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  }
  float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 3; i++) { v += a * vnoise(p); p = p * 2.03 + vec2(17.1, 9.7); a *= 0.5; }
    return v;
  }
`;

export const QUAD_VERTEX = /* glsl */ `
  varying vec2 vUv;
  void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

/** Slow blooms of colour in a dark room, with a little grain. */
export const FIELD_FRAGMENT = /* glsl */ `
  uniform float uTime;
  uniform vec2 uRes;
  uniform float uLift;
  varying vec2 vUv;
  ${NOISE}
  vec2 warp;
  vec3 bloom(vec2 p, vec2 c, float r, vec3 col, float t) {
    vec2 d = (p - c) * vec2(uRes.x / uRes.y, 1.0) + warp;
    float f = exp(-dot(d, d) / (r * r));
    return col * f;
  }
  void main() {
    vec2 p = vUv;
    float t = uTime;
    warp = 0.06 * vec2(fbm(p * 2.0 + t * 0.05), fbm(p * 2.0 - t * 0.04 + 5.0)) - 0.03;
    vec3 base = vec3(0.027, 0.039, 0.051);
    vec3 col = base;
    col += bloom(p, vec2(0.12 + 0.03 * sin(t * 0.07), 0.9 + 0.02 * cos(t * 0.05)), 0.42, vec3(0.36, 0.37, 0.93) * 0.34, t);
    col += bloom(p, vec2(0.96 + 0.02 * cos(t * 0.06), 0.62 + 0.03 * sin(t * 0.08)), 0.36, vec3(0.12, 0.43, 0.40) * 0.42, t + 3.0);
    col += bloom(p, vec2(0.30, 0.02 + 0.03 * sin(t * 0.09)), 0.34, vec3(0.98, 0.74, 0.59) * 0.16, t + 7.0);
    col += bloom(p, vec2(0.62 + 0.03 * sin(t * 0.05), 0.35), 0.22, vec3(0.18, 0.82, 0.06) * 0.06, t + 11.0);
    // light behind the glass, so the slab has something to bend
    col += bloom(p, vec2(0.74 + 0.02 * sin(t * 0.06), 0.5 + 0.03 * cos(t * 0.07)), 0.3, vec3(0.62, 0.56, 0.95) * 0.2, t + 17.0);
    col += bloom(p, vec2(0.86, 0.3 + 0.02 * sin(t * 0.08)), 0.2, vec3(0.98, 0.72, 0.6) * 0.12, t + 23.0);
    col += uLift * vec3(0.05, 0.06, 0.07);
    // soft haze, brighter toward the top right where the key light lives
    col += 0.035 * smoothstep(0.2, 1.0, p.y) * smoothstep(0.1, 0.9, p.x);
    // vignette
    float v = smoothstep(1.35, 0.45, length((p - 0.5) * vec2(1.15, 1.0)));
    col *= mix(0.55, 1.0, v);
    gl_FragColor = vec4(col, 1.0);
  }
`;

/** Full-resolution copy of the backdrop with fine grain so nothing bands. */
export const BACKDROP_FRAGMENT = /* glsl */ `
  uniform sampler2D uMap;
  uniform float uTime;
  varying vec2 vUv;
  float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
  void main() {
    vec4 c = texture2D(uMap, vUv);
    float g = hash21(gl_FragCoord.xy + fract(uTime) * 100.0) - 0.5;
    gl_FragColor = vec4(c.rgb + g * 0.016, 1.0);
  }
`;

export const SCREEN_VERTEX = /* glsl */ `
  varying vec2 vUv;
  void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
`;

/** A screenshot with rounded corners, a hairline edge and a faint glow. */
export const SCREEN_FRAGMENT = /* glsl */ `
  uniform sampler2D uMap;
  uniform vec2 uSize;
  uniform vec2 uUvScale;
  uniform vec2 uUvOffset;
  uniform float uRadius;
  uniform float uDim;
  uniform float uFade;
  varying vec2 vUv;
  float rrect(vec2 p, vec2 b, float r) { vec2 q = abs(p) - b + r; return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r; }
  void main() {
    vec2 p = (vUv - 0.5) * uSize;
    float d = rrect(p, uSize * 0.5, uRadius);
    float aa = fwidth(d) * 1.2;
    float inside = 1.0 - smoothstep(-aa, aa, d);
    if (inside <= 0.001) discard;
    vec4 tex = texture2D(uMap, vUv * uUvScale + uUvOffset);
    vec3 col = tex.rgb * uDim;
    // hairline bezel
    float edge = 1.0 - smoothstep(0.0, 2.2, abs(d + 1.1));
    col = mix(col, vec3(0.92, 0.95, 0.97), edge * 0.35);
    gl_FragColor = vec4(col, inside * uFade);
  }
`;

/* The slab breathes: its outline swells and settles along a slow noise field. */
export const GLASS_VERTEX = /* glsl */ `
  uniform float uTime;
  uniform float uWobble;
  varying vec3 vNormalV;
  varying vec3 vPosV;
  varying vec3 vLocal;
  ${NOISE}
  void main() {
    vLocal = position;
    vec2 q = position.xy * 0.0032 + vec2(uTime * 0.05, -uTime * 0.04);
    float w = fbm(q) - 0.5;
    float wx = fbm(q + vec2(0.02, 0.0)) - 0.5 - w;
    float wy = fbm(q + vec2(0.0, 0.02)) - 0.5 - w;
    vec3 displaced = position + normal * w * uWobble;
    vec3 n = normalize(normal - vec3(wx, wy, 0.0) * uWobble * 0.06);
    vNormalV = normalize(normalMatrix * n);
    vec4 mv = modelViewMatrix * vec4(displaced, 1.0);
    vPosV = mv.xyz;
    gl_Position = projectionMatrix * mv;
  }
`;

/**
 * Liquid glass: the view-space normal is bent by pointer ripples and a slow
 * flow, then used to refract the backdrop per colour channel (dispersion), with
 * a Fresnel rim, two specular lights and a thin-film tint at grazing angles.
 */
export const GLASS_FRAGMENT = /* glsl */ `
  uniform sampler2D uBackdrop;
  uniform sampler2D uRipple;
  uniform vec2 uRes;
  uniform vec2 uSize;      // slab width/height in local units
  uniform float uDepth;    // slab depth
  uniform vec2 uRippleTexel;
  uniform float uTime;
  uniform float uIor;
  uniform float uDispersion;
  uniform float uThickness;
  uniform float uRough;
  uniform float uFlow;
  uniform vec3 uTint;
  varying vec3 vNormalV;
  varying vec3 vPosV;
  varying vec3 vLocal;
  ${NOISE}

  vec3 tap(vec2 uv, vec2 off, float disp) {
    vec3 c;
    c.r = texture2D(uBackdrop, uv + off * (1.0 + disp)).r;
    c.g = texture2D(uBackdrop, uv + off).g;
    c.b = texture2D(uBackdrop, uv + off * (1.0 - disp)).b;
    return c;
  }

  void main() {
    vec2 ruv = vLocal.xy / uSize + 0.5;
    float front = smoothstep(0.35, 0.49, vLocal.z / uDepth);

    // ripples (pointer) — heights stored around 0.5
    float h  = texture2D(uRipple, ruv).r - 0.5;
    float hx = texture2D(uRipple, ruv + vec2(uRippleTexel.x, 0.0)).r - 0.5 - h;
    float hy = texture2D(uRipple, ruv + vec2(0.0, uRippleTexel.y)).r - 0.5 - h;

    // slow liquid flow across the surface
    vec2 fp = vLocal.xy / max(uSize.x, uSize.y) * 3.2;
    float t = uTime * 0.11;
    float f0 = fbm(fp + vec2(t, -t * 0.7));
    float fx = fbm(fp + vec2(0.035, 0.0) + vec2(t, -t * 0.7)) - f0;
    float fy = fbm(fp + vec2(0.0, 0.035) + vec2(t, -t * 0.7)) - f0;

    vec3 n = normalize(vNormalV + vec3(hx, hy, 0.0) * 16.0 * front + vec3(fx, fy, 0.0) * uFlow * front);
    vec3 v = normalize(-vPosV);
    float ndv = clamp(dot(n, v), 0.0, 1.0);
    float fres = pow(1.0 - ndv, 3.2);

    // screen-space refraction
    vec2 uv = gl_FragCoord.xy / uRes;
    vec3 r = refract(-v, n, 1.0 / uIor);
    vec2 off = r.xy * uThickness * vec2(uRes.y / uRes.x, 1.0) * (0.55 + 0.45 * (1.0 - front));

    // dispersion lives mostly in the bevel; a handful of taps soften the edges
    float disp = uDispersion * (0.25 + 0.75 * (1.0 - front));
    vec3 col = tap(uv, off, disp) * 0.4;
    float rr = uRough * (0.4 + 1.2 * (1.0 - front));
    col += tap(uv, off + vec2( rr,  0.0), disp) * 0.15;
    col += tap(uv, off + vec2(-rr,  0.0), disp) * 0.15;
    col += tap(uv, off + vec2(0.0,  rr * uRes.x / uRes.y), disp) * 0.15;
    col += tap(uv, off + vec2(0.0, -rr * uRes.x / uRes.y), disp) * 0.15;

    // a touch of brightness and cool tint, like thick clear glass
    col = col * (1.06 - fres * 0.5) + uTint * 0.035;

    // lights: a broad warm key from the top left, a mint rim from below right
    vec3 l1 = normalize(vec3(-0.55, 0.75, 0.6));
    vec3 l2 = normalize(vec3(0.7, -0.5, 0.45));
    vec3 h1 = normalize(l1 + v);
    vec3 h2 = normalize(l2 + v);
    float s1 = pow(max(dot(n, h1), 0.0), 160.0) * 0.9 + pow(max(dot(n, h1), 0.0), 18.0) * 0.08;
    float s2 = pow(max(dot(n, h2), 0.0), 90.0) * 0.35;
    col += vec3(1.0, 0.98, 0.94) * s1 + vec3(0.72, 0.94, 0.88) * s2;

    // thin-film colour at grazing angles, and the bright rim itself
    vec3 film = mix(vec3(0.72, 0.94, 0.88), vec3(0.78, 0.7, 0.98), 0.5 + 0.5 * sin(ndv * 14.0 + vLocal.y * 0.01));
    col += film * fres * 0.34 + vec3(1.0) * fres * fres * 0.5;

    gl_FragColor = vec4(col, 1.0);
  }
`;
