import { useEffect, useRef } from 'react';
import { ArrowDown, ArrowRight } from 'lucide-react';
import { Phone } from '../../components/Device';
import { Magnetic } from '../../components/Magnetic';
import { Reveal, SplitText } from '../../components/Reveal';
import { img } from '../../data/img';
import { profile } from '../../data/profile';
import { projects } from '../../data/projects';
import { GlassHero, useGlassHero } from '../../gl/GlassHero';
import type { HeadlineRun, ScreenSpec } from '../../gl/glassScene';
import { useRouter, workHref } from '../../lib/router';
import { onScrollFrame } from '../../lib/scroll';

const clamp = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value));

const HEADLINE_TEXT = 'I design health products that hold up in real life.';
const HEADLINE: HeadlineRun[][] = [
  [{ text: 'I design health' }],
  [{ text: 'products that' }],
  [{ text: 'hold up', serif: true }, { text: ' in real life.' }],
];

/* Screens drift behind the glass; positions are fractions of the hero box and
   depth is in the scene's pixel units (further back reads smaller and slower). */
const PHONE = 780 / 1688;
const SCREENS: ScreenSpec[] = [
  { src: img('trackya/app-1.webp'), w: 0.125, x: 0.6, y: 0.5, z: -380, rot: -0.06, aspect: PHONE },
  { src: img('moodloop/app-08.webp'), w: 0.13, x: 0.79, y: 0.42, z: -760, rot: 0.05, aspect: PHONE },
  { src: img('physicify/final-calendar-planning.webp'), w: 0.12, x: 0.905, y: 0.8, z: -520, rot: 0.08, aspect: PHONE },
  { src: img('planneregy/app-mock-1.webp'), w: 0.115, x: 0.7, y: 0.86, z: -1000, rot: -0.04, aspect: PHONE },
  { src: img('carework/shot-04.webp'), w: 0.34, x: 0.83, y: 0.16, z: -1350, rot: 0.02, aspect: 1926 / 1203 },
];

const fan = [
  { src: img('physicify/final-calendar-planning.webp'), alt: '' },
  { src: img('moodloop/app-10.webp'), alt: '' },
  { src: img('trackya/app-1.webp'), alt: '' },
  { src: img('moodloop/app-08.webp'), alt: '' },
  { src: img('planneregy/app-mock-1.webp'), alt: '' },
];

export function Hero() {
  const root = useRef<HTMLElement>(null);
  const title = useRef<HTMLHeadingElement>(null);
  const { link } = useRouter();
  const [glass, disableGlass] = useGlassHero();
  const slot = glass !== false; // undecided or on: the heading reserves space for the drawn headline

  useEffect(() => onScrollFrame(({ y, vh }) => {
    root.current?.style.setProperty('--hp', clamp(y / (vh * 0.9)).toFixed(4));
  }), []);

  return (
    <section ref={root} className={`hero${slot ? ' hero--glass' : ' hero--flat'}`} id="top" aria-labelledby="hero-title">
      {glass && <GlassHero host={root} slot={title} lines={HEADLINE} screens={SCREENS} onTooSlow={disableGlass} />}

      <div className="shell hero__inner">
        <Reveal kind="fade" delay={120} className="hero__meta">
          <span className="pill"><i className="dot" aria-hidden="true" />{profile.availability}</span>
          <span className="mono hero__meta-right">Product designer · PhD researcher, Georgia Tech</span>
        </Reveal>

        {slot ? (
          <h1 ref={title} id="hero-title" className="display hero__title hero__title--slot">
            <span className="sr-only">{HEADLINE_TEXT}</span>
          </h1>
        ) : (
          <SplitText as="h1" id="hero-title" className="display hero__title" delay={180} text="I design health products that *hold up* in real life." />
        )}

        <div className="hero__row">
          <Reveal delay={700} className="hero__lede">
            <p className="lede">
              I take ideas from first interview to Figma to shipped app, then live with the result: multi-week field studies with the people who use it, not five-minute tests.
            </p>
          </Reveal>
          <Reveal delay={820} className="hero__cta">
            <Magnetic>
              <a className="btn" href={workHref(projects[0].slug)} onClick={link(workHref(projects[0].slug))}>
                Start with {projects[0].name} <ArrowRight size={18} aria-hidden="true" />
              </a>
            </Magnetic>
            <a className="hero__scroll mono" href="#/" onClick={link('#/', { section: 'work' })}>
              Selected work ({String(projects.length).padStart(2, '0')}) <ArrowDown size={14} aria-hidden="true" />
            </a>
          </Reveal>
        </div>
      </div>

      {glass === false && (
        <Reveal kind="fade" delay={300} className="hero__fan" aria-hidden="true">
          <div className="hero__slab glass glass--slab" />
          {fan.map((shot, index) => (
            <div key={shot.src} className={`hero__phone hero__phone--${index}`} style={{ '--d': `${480 + Math.abs(index - 2) * 120}ms` } as React.CSSProperties}>
              <Phone shot={shot} eager decorative />
            </div>
          ))}
        </Reveal>
      )}

      <Reveal kind="fade" delay={1300} eager className="hero__foot mono" aria-hidden="true">
        <span>Scroll</span>
        <i className="hero__foot-line" />
        <span>Look through the glass</span>
      </Reveal>
    </section>
  );
}
