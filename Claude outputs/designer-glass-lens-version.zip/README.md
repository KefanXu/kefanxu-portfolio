# Kefan Xu — academic portfolio

A personal website for a PhD student in Human-Centered Computing at Georgia Tech. The design combines a white canvas, Crimson Text typography, muted teal, original sculptural artwork, and restrained interaction.

## What is included

- An image-free editorial introduction with a two-line serif headline, an inset italic accent, a fine green rule, and supporting columns for the research statement, affiliation, and profile links.
- An introduction followed by biography and education, research perspective, selected projects, research practice, publications, and contact.
- An abstract orbital illustration that changes from individual reflection to caregiving relationships to a wider ecology of care. Scroll position rotates its orbit layers and moves the sculptural forms. It stays beside the text above 760px and adapts to a compact sticky presentation on smaller screens.
- Nine physical book covers featuring original raster ceramic illustrations, scroll-driven perspective, and an animated opening spread whose paper expands into the project reader. All nine lead into project readers; modified clicks retain normal browser link behavior. Reduced-motion preferences skip the opening animation.
- An editorial research-practice sequence with numbered stages for design, development, and deployment, paired with methods and linked project evidence. Brief entrance reveals replace the earlier sculptural illustrations.
- Nine project readers with context, design, study evidence, contributions, related papers, and previous/next navigation. Project links use shareable `#project/ID` URLs, so a static host can open them directly without server-side routing.
- Pill-shaped outlined controls and primary actions, with underlined secondary links and active navigation. Publication search and year fields use simple bottom rules.
- Searchable publication disclosures with author highlighting, abstracts or labeled abstract excerpts, related project links, and selectable/copyable BibTeX citations. Opening a paper reveals its details; collapsed panels remain outside keyboard focus.
- A brief typography entrance, staggered biography and publication reveals, and a reading-progress line. The introduction has no continuous scroll animation and honors reduced-motion preferences.

## Run locally

Use Node.js 20.19 or newer; clean installation and production builds were verified with Node.js 24.19.0.

```sh
npm ci
npm run dev
```

## Build and preview

```sh
npm run build
npm run preview
```

The existing Scholar sync runs before development and production builds. If Scholar is unavailable, it retains the checked-in publication data. Run `npm run sync:scholar` to refresh explicitly.

The default build uses `/`, suitable for Vercel and other hosts that serve the site from a root domain. Leave `BASE_PATH` unset for production deployment.

## Edit content and presentation

- `src/App.tsx`: navigation, section order, and contact.
- `src/components/academic/HeroIntro.tsx` and `HeroIntro.css`: image-free editorial introduction, responsive headline, academic affiliation, research statement, and profile links.
- `src/components/academic/About.tsx`: biography and education.
- `src/components/academic/HeroSculpture.tsx`: retained artwork component from the previous introduction; the current homepage does not load it.
- `src/components/academic/heroSculptureScene.ts`, `ceramicMaterials.ts`, and `sculptureGeometry.ts`: retained experimental Three.js implementation; the current homepage does not load it.
- `src/components/academic/ResearchPerspective.tsx`: three research perspectives and the animated SVG illustration.
- `src/components/academic/ResearchGallery.tsx`: nine-book collection, scroll response, and the book-opening transition.
- `src/components/academic/ResearchBook.tsx`: metadata and image paths for all nine original raster book illustrations, with live HTML cover titles.
- `src/components/academic/ProjectDetail.tsx`: native dialog, project routes, focus restoration, and case-study layout.
- `src/data/projectCaseStudies.ts`: detailed project copy, study evidence, figures, source credits, and related papers.
- `src/data/portfolio.ts`: original project contributions, roles, collaborations, periods, and methods.
- `src/components/academic/ResearchPractice.tsx` and `ResearchPractice.css`: numbered research-practice stages, methods, tools, and related project evidence.
- `src/components/academic/Publications.tsx`: publication search, year filtering, expandable records, abstracts, related projects, and citations.
- `src/data/publications.ts` and `src/data/publications.generated.json`: publication data and local enrichments.
- `src/index.css` and component stylesheets: typography, layout, responsiveness, and motion.
- `src/assets/KefanXu_CV.pdf`: curriculum vitae.

## Project media

Fonts are self-hosted with their licenses in `src/assets/fonts/academic/`. Conceptual artwork provenance is documented in `ARTWORK.md`. All nine book illustrations are optimized WebPs in `public/images/`. The hero and gallery illustrations do not depict research systems or participants.

Project documentation lives in `public/images/projects/`:

- Trackya includes the proposed MotionShift interface figure from the related 2025 workshop paper. The case study identifies it as a proposed design, with source and license attribution.
- PECSS includes three panels from the published CHR prototype figure. The case study identifies these as mock-data research interfaces and credits the source paper.
- DUCSS and Moodloop include poster-first, privacy-enhanced YouTube players that open directly inside each project reader. Moodloop also includes original Figma interface and research-design exports.
- CareWork includes three legible interface stages from the supplied manuscript. EcoCare includes the proposed interface from the supplied thesis. The readers distinguish completed study evidence from proposed work.
- Caregiving includes the published four-phase analysis and temporal sense-making framework. Planneregy combines its author-supplied interaction sequence with published workflow, study, and interview figures. Physicify includes three original interface screens from the supplied Figma source.

To add project documentation, place image files in `public/images/projects/`, add a `figures` array of `{ src, alt, caption }` entries to the relevant record in `src/data/projectCaseStudies.ts`, and supply `figureSource` attribution when appropriate. Keep project evidence and personal contributions consistent with the original research records.

## Interaction and verification

Navigation uses native document scrolling, and motion honors the operating system’s reduced-motion preference. Project readers use native modal dialogs. Keyboard-opened readers restore focus to the exact initiating link, while pointer-opened readers close without leaving a Safari focus ring. Publication disclosure buttons expose their expanded state and keep collapsed panels inert; citations use native HTML details.

See `QA.md` for the clean-build results, asset-path checks, browser interactions exercised, and verification limits.

## Designer mode (`/design/`)

The site has a second mode for product/UX design roles. It is a separate HTML entry with its own styles, so the academic site above is untouched: same markup, same stylesheet bundle, same behaviour.

The designer mode is a dark, luminous room built around one idea: **look through the glass to see the research underneath.**

- **Glass hero** (`src/design/gl/`). A WebGL slab of liquid glass (three.js, loaded lazily so only capable devices download it) floats over the headline and a cluster of app screens, refracting them with dispersion at its edges. The headline is drawn into the scene so the glass can bend it; the real `<h1>` keeps the text for assistive tech. The pointer ripples the surface, the slab breathes and tilts, and everything lifts away as you scroll. Screens narrower than 900px, reduced motion, machines without WebGL 2 and machines that cannot hold a frame rate (the scene measures itself and steps down to a low-quality mode first) get the DOM hero instead. `?gl=force` keeps the scene on for software renderers; `?gl=lite` starts it in low quality.
- **The field and the lens** (`pages/home/Field.tsx`, `data/beneath.ts`). Selected work is a row of glass panes the page scroll carries past the viewport. A lens follows the pointer; wherever it rests on a pane, the glass gives way to the paper underneath — the recruitment flyer, study plan, wireframes or framework — with a field note and two numbers from the study. On touch and keyboard a "Look beneath" button lifts the whole pane. `beneath.ts` holds that content; nothing there is a participant quote.
- **Glass surfaces.** One recipe (`.glass` in `styles/base.css`) for nav, pills, buttons, cards and case-study panels; a fixed light field (`.room`) behind every section, built from soft gradients rather than blur filters so it composites cheaply.

- **Switching.** A small pill, `Researcher | Designer`, floats at the bottom of both modes (`src/mode/modeSwitch.ts`, `mode-switch.css`). It is plain TypeScript outside either React tree. Clicking it raises a curtain, loads the other entry, and lifts the curtain on arrival. It tucks away while scrolling down, works as a normal link without JavaScript or with reduced motion, and resets correctly from the back/forward cache. The academic entry mounts it with one call in `src/main.tsx`; nothing in `App.tsx` changed.
- **Entry and routing.** `design/index.html` → `src/design/main.tsx`. Vite builds both entries (`vite.config.ts`), so static hosts serve the designer mode at `/design/` with no rewrites. Inside it, a tiny hash router (`src/design/lib/router.tsx`) handles `#/` and `#/work/<slug>` with a cover → swap → reveal page transition, and restores the scroll position when returning to the index.
- **Content.** Everything editable lives in `src/design/data/`: `profile.ts` (hero, approach, experience, recognition, toolkit, archive) and one file per case study in `projects/`. A case study is a typed list of blocks (`types.ts`): text, pinned device sequence, gallery, figure (plain, card, browser, phone, pan), insights, identity, live demo, video, outcome. Order on the home page is set in `projects.ts`.
- **Motion.** Lenis smooth scrolling and one shared frame loop (`lib/scroll.ts`); masked word reveals and scroll reveals (`components/Reveal.tsx`, which also sweeps pending elements on scroll frames so a stalled IntersectionObserver never leaves anything hidden); cover compositions with pointer parallax (`components/Covers.tsx`); a pinned device whose screen follows the text and phone strips that the page scroll pans from first screen to last (`components/Blocks.tsx`; on touch they are a native swipe); a reading-progress line on case studies; count-up stats; a trailing cursor label; magnetic buttons. All of it stands down under `prefers-reduced-motion`.
- **Figures.** Detailed figures (dashboards, diagrams, posters) open in a keyboard-friendly lightbox (`components/Lightbox.tsx`). Every `<img>` reserves its space from `src/design/data/imageSizes.json`, so lazy images never shift the layout. After adding or replacing files in `public/images/design/`, regenerate that table with `node scripts/design-image-sizes.mjs` (no dependencies; a missing entry only means the image loads without reserved space).
- **Live demos** (`src/design/demos/`): Trackya's capsule grid with a personal threshold, the early Moodloop mood scale rebuilt from the Figma vectors, Planneregy's weekly loop, and an illustrative EcoCare ecology with life-changing events.
- **Type.** Instrument Sans, Instrument Serif and Geist Mono, self-hosted with their OFL licenses in `src/design/assets/fonts/`.
- **Tailwind.** `tailwind.config.js` excludes `src/design` and `src/mode` from its scan, which keeps the academic CSS bundle byte-identical to before.

Designer-mode images are in `public/images/design/`; provenance is recorded in `ASSETS.md`.
